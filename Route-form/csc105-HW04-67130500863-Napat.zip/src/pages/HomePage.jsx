import React from 'react'

const HomePage = () => {
    return(
        <h1 className="text-2xl font-bold text-indigo-900 mt-6 ml-8">Welcome to the Home Page.</h1>
    );
};

export default HomePage;